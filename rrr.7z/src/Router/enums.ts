export enum ERouterPaths {
    HOME = '/',
    ABOUT = '/about',
}
