export type TBootstrapColor =
    | 'primary'
    | 'success'
    | 'secondary'
    | 'danger'
    | 'warning'
    | 'info'
    | 'light'
    | 'dark';
