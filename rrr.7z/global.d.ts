export declare global {
    type TTimeout = ReturnType<typeof setTimeout> | null;
}
