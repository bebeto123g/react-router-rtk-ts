export enum EBootstrapColors {
    PRIMARY = 'primary',
    SUCCESS = 'success',
    SECONDARY = 'secondary',
    DANGER = 'danger',
    WARNING = 'warning',
    INFO = 'info',
    LIGHT = 'light',
    DARK = 'dark',
}
